# Whether Weather App

## Project Description

Whether Weather is a small, static weather dashboard built with HTML, Bulma, CSS, and Eleventy (11ty). The project allows users to view weather summaries for selected cities and navigate to individual city forecast pages. A simple "Settings" page lets users choose which cities appear on their dashboard.

The purpose of this project is to demonstrate:

* Use of Eleventy as a static site generator
* Templating with Bulma
* Basic client-side interactivity using JavaScript

This project was developed for a web development academic assignment.

---

## Installation Instructions

### Install Eleventy

#### Steps

1. Open a terminal in the project root directory 

2. Input the below:

```bash
npm install -g @11ty/eleventy
```

### Run Eleventy

1. Open a terminal in the project root directory 

2. Input the below:

```bash
eleventy --serve
```

3. Open your browser and visit:

http://localhost:8080

This should display your site.

---

## Usage

### Dashboard

* The homepage displays weather cards for selected cities
* Each card shows a brief summary and includes a "View City Forecast" link

### City Forecast Pages

* Clicking "View City Forecast" opens a dedicated forecast page for that city
* Each city page is generated using Bulma and Eleventy templates

### Settings Page

* Navigate to `/settings/`
* Select or deselect cities using checkboxes
* The checkboxes currently do nothing.

---

## Known Limitations

* This project is built as a **static site** using Eleventy, meaning user
  preferences are not persisted across sessions without client-side scripting.
* The "Settings page" is a visual demonstration only and does not currently
  store or apply user-selected preferences.
- Weather data is static and hard-coded for demonstration purposes and does
  not update in real time.
- City pages must be created manually; adding new cities requires editing
  template files.
- The project does not include server-side functionality.
- Styling is intentionally minimal to focus on structure, templating, and
  accessibility rather than advanced UI interactions.

---

## Documentation

* Eleventy Documentation: [https://www.11ty.dev/docs/](https://www.11ty.dev/docs/)
* Nunjucks Templating: [https://mozilla.github.io/nunjucks/](https://mozilla.github.io/nunjucks/)
* JavaScript & Web APIs: [https://developer.mozilla.org/](https://developer.mozilla.org/)

---

## Contributing Guidelines

This project is only for educational purposes. However, suggestions and improvements are welcome.

---

## License

You are free to use, modify, and distribute this project with attribution.
However, the icons found on the "Air Quality Index" page should be attributed to https://www.flaticon.com/.

---

## Contact Information

For questions or feedback, please contact me at 20119117@setu.ie

---

## Acknowledgements

* Eleventy (11ty) for static site generation
* Bulma for templating support
* Weather icons and example assets used for educational purposes
* Inspiration from modern weather dashboard UI patterns
