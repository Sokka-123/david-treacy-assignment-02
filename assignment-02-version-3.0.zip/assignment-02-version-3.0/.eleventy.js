module.exports = function (eleventyConfig) {

  // Copy CSS folder directly to output
  eleventyConfig.addPassthroughCopy("src/css");

  // Optional: copy images/icons if you add them later
  eleventyConfig.addPassthroughCopy("src/images");

  return {
    dir: {
      input: "src",          
      includes: "_includes",
      output: "_site"        // for Netlify
    },

    templateFormats: ["njk", "html"],

    htmlTemplateEngine: "njk",
    markdownTemplateEngine: "njk"
  };
};
